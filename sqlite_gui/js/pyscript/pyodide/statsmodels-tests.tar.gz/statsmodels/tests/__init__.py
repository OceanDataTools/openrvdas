# Tests for the package behavior of statsmodels
