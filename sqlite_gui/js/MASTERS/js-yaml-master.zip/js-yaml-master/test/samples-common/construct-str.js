'use strict';

module.exports = {
  string: 'abcd'
};
