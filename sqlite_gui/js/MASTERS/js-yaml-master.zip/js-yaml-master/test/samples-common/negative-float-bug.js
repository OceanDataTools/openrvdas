'use strict';

module.exports = -1.0;
