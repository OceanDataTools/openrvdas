'use strict';

module.exports = {
  foo: {
    baz: 'bat',
    foo: 'duplicate key'
  }
};
