'use strict';

module.exports = 'implicit UTF-8';
