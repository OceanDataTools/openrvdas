'use strict';

module.exports = {
  'Block style': {
    Clark: 'Evans',
    Brian: 'Ingerson',
    Oren: 'Ben-Kiki'
  },
  'Flow style': {
    Clark: 'Evans',
    Brian: 'Ingerson',
    Oren: 'Ben-Kiki'
  },
  'foo,bar': 'baz'
};
