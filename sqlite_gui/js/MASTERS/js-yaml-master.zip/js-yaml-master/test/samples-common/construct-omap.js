'use strict';

module.exports = {
  Bestiary: [
    { aardvark : 'African pig-like ant eater. Ugly.'        },
    { anteater : 'South-American ant eater. Two species.'   },
    { anaconda : 'South-American constrictor snake. Scaly.' }
  ],
  Numbers: [
    { one   : 1 },
    { two   : 2 },
    { three : 3 }
  ]
};
