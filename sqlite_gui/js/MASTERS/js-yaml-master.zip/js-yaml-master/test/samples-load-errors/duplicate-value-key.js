'use strict';

module.exports = { foo: 'bar', '=': 2 };
